# CompassCAD Core

Hey there, human. You should [read this to get started on how to embed CompassCAD Core!](https://zeankundev.notion.site/Working-with-CompassCAD-Core-c63d0474a42b406596dd45bb04a7acf0)